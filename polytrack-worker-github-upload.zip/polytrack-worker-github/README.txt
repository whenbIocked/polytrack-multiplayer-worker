POLYTRACK MULTIPLAYER WORKER — BROWSER-ONLY DEPLOYMENT

This project is for the Cloudflare Worker named: multiplayer
It is NOT for upload to Cloudflare Pages as static website files.
It intentionally includes wrangler.toml; Cloudflare Pages rejecting wrangler.toml is unrelated because this file belongs in the Worker project.

NO POWERSHELL REQUIRED: USE THE CLOUDFLARE GITHUB INTEGRATION

1. Extract this ZIP on your computer.
2. On github.com, create a new repository named polytrack-multiplayer-worker.
3. In the new repository, choose Add file > Upload files.
4. Upload these three files from this extracted folder to the repository root:
   - index.js
   - wrangler.toml
   - package.json
5. Commit the files to the repository's main branch.
6. In Cloudflare, go to Workers & Pages > multiplayer > Settings > Builds.
7. Choose Connect and connect the GitHub repository you just created.
8. Leave the root directory blank (repository root). Use deploy command: npx wrangler deploy.
9. Save the settings and trigger a build/deploy from the Builds area if it does not start automatically.
10. Check the build logs. The build must succeed before testing the Worker again.

The wrangler.toml is meant for the Worker build. DO NOT upload it to the PolyTrack Pages website.

After deployment, test:
https://multiplayer.spicylemontrain3.workers.dev/api/health
Expected service value: polytrack-0.6.3-signaling

Note: a successful deployment provisions the Durable Object class/binding, but live invite interoperability still needs to be tested against PolyTrack 0.6.3. This package is not a guarantee that invites/races work until that end-to-end test succeeds.
